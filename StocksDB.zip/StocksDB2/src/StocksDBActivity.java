import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Statement;


public class StocksDBActivity {
	
	 //Database connection settings
	 private Connection connect = null;
	 private Statement statement = null;
	 private PreparedStatement preparedStatement = null;
	 private ResultSet resultSet = null;
	 private int IndividualID_counter = 0;
	public StocksDBActivity(){
		try {
			initialize_database();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	 
	 
	public void initialize_database() throws SQLException, ClassNotFoundException{
		  Class.forName("com.mysql.jdbc.Driver");
	      // setup the connection with the DB.
	      connect = DriverManager.getConnection("jdbc:mysql://localhost/finance?"
	              + "user=root&password=livetowin");//ToDo
	      statement = connect.createStatement();
	}

	public void execute_exchange(String name, String stock1,
			String stock2, String date) {
		try {
			preparedStatement = connect
			.prepareStatement("insert into  FEEDBACK.COMMENTS values (default, ?, ?, ?, ? , ?, ?)");
			//preparedStatement.setString(1, companySymbol); // Symbol
			//preparedStatement.setString(2, company[0]); // Date
			//preparedStatement.setDouble(3, Double.parseDouble(company[1]));//open
			//preparedStatement.setDouble(4, Double.parseDouble(company[2]));//hihg
			//preparedStatement.setDouble(5, Double.parseDouble(company[3]));//low
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/*buy|sell,name,stock symbol|fund name,dollar amount,date*/
	public void execute_sell(String name, String Symbol_fund_name, String dollar_amount, String Date ) {
		try {
			preparedStatement = connect
			.prepareStatement("insert into  FEEDBACK.COMMENTS values (default, ?, ?, ?, ? , ?, ?)");
			preparedStatement.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void execute_buy(String name, String symbol, String dollar_amount, String date) {
		try {
			
			//Checks if name is a portfolio name
			preparedStatement = connect
					.prepareStatement("SELECT name FROM portfolio WHERE name = ? ; ");
			preparedStatement.setString(1,name);
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next() == false){ //enters if name is individual
				
				//Checks if symbol is portfolio name
				preparedStatement = connect
				.prepareStatement("SELECT name FROM portfolio WHERE name  = ? ; ");
				preparedStatement.setString(1,symbol);
				rs = preparedStatement.executeQuery();
				
				//Write individual investing in portfolio QUERY here
				
				if(rs.next() == false){ //enters if buying from company
					
					//Updates Individual_Activity Table
					preparedStatement = connect
							.prepareStatement("insert into FINANCE.INDIVIDUAL_ACTIVITY values (default, ?,?,?,?,?,?)");
					
					preparedStatement.setString(1, date);
					preparedStatement.setInt(2, 0);
					preparedStatement.setDouble(3, Double.parseDouble(dollar_amount));
					preparedStatement.setString(4, symbol);
					preparedStatement.setString(5, "buy");
					
						//Query that finds individual_id
						PreparedStatement preparedStatement2 = connect
								.prepareStatement("SELECT individual_id FROM individual WHERE name  = ? ;");
						preparedStatement2.setString(1,name);
						rs = preparedStatement2.executeQuery();
						rs.next();		
						preparedStatement.setInt(6,rs.getInt("individual_id"));
						
						preparedStatement.executeUpdate();
						
					//Updates Individual Table (Cash)
					PreparedStatement getCash = connect.prepareStatement("SELECT cash FROM individual WHERE name = ? ;");	
					getCash.setString(1, name);
					rs = getCash.executeQuery();
					rs.next();
					
//					PreparedStatement cashUpdate = connect
//							.prepareStatement("UPDATE individual SET cash = "+rs.getDouble("cash")-Double.parseDouble(dollar_amount) +" WHERE id in (100, 101)");
						
				}else{//buying from portfolio
					preparedStatement = connect
							.prepareStatement("insert into FINANCE.INDIVIDUAL_ACTIVITY values (default, ?,?,?,?,?,?)");
					
					preparedStatement.setString(1, date);
					preparedStatement.setInt(2, 0);
					preparedStatement.setDouble(3, Double.parseDouble(dollar_amount));
					preparedStatement.setString(4, symbol);
					preparedStatement.setString(5, "buy");
					
					PreparedStatement preparedStatement2 = connect
							.prepareStatement("SELECT individual_id FROM individual WHERE name  = ? ;");
					
					preparedStatement2.setString(1,name);
					rs = preparedStatement2.executeQuery();
					
					rs.next();		
					preparedStatement.setInt(6,rs.getInt("individual_id"));
					
				}
				
			}else{
				//Write portfolio investing in company QUERY here
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void execute_individual(String name , String dollar_figure, String date) {
		try {
			preparedStatement = connect
					.prepareStatement("insert into Finance.individual values (default,?, ?, ?,?)");
					
					//preparedStatement.setInt(1, 2);
					preparedStatement.setString(1, name);
					preparedStatement.setDouble(2, Double.parseDouble(dollar_figure));
					preparedStatement.setDouble(3, Double.parseDouble(dollar_figure));
					preparedStatement.setString(4, date);
						
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//fund,name,dollar,figure,date
	@SuppressWarnings("deprecation")
	public void execute_fund(String name, String dollar_figure, String date) {
	
		try {
			String CompanyInfo = getQuote(name);
			preparedStatement = connect
			.prepareStatement("insert into Finance.portfolio values (?, ?, ?,?)");
			
			preparedStatement.setString(1, name);
			preparedStatement.setDouble(2, Double.parseDouble(dollar_figure));
			preparedStatement.setDouble(3, Double.parseDouble(dollar_figure));
			preparedStatement.setString(4, date);
			
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
	public void read_file(File file) throws SQLException, ClassNotFoundException, IOException {
		  Scanner inFile = new Scanner(file);  
		  BufferedReader br = new BufferedReader(new FileReader(file));
		  String commandInfo;
		  String cvsSplitBy = ",";
		  while ((commandInfo = br.readLine()) != null) {
			String[] company = commandInfo.split(cvsSplitBy);
			if(company[0].equals("fund"))
				this.execute_fund(company[1], company[2], company[3]);
			else if (company[0].equals("individual"))
				this.execute_individual(company[1], company[2], company[3]);
			else if (company[0].equals("buy"))
				this.execute_buy(company[1], company[2], company[3], company[4]);
			else if (company[0].equals("sell"))
				this.execute_sell(company[1], company[2], company[3], company[4]);
			else if (company[0].equals("sellbuy"))
				this.execute_exchange(company[1], company[2], company[3], company[4]);
			else 
				System.out.println("Unknown Command");
		  }
		
	}

	private String getQuote(String Company) throws IOException{
		InputStream inputStream = null;

		try {
			
			// TODO: Modify URL to request all data for multiple companies
			// all at one time
			
			//URL url = new URL("http://finance.yahoo.com/d/quotes.csv?s="+company+"&f=b2kj");
			URL url = new URL("http://finance.yahoo.com/d/quotes.csv?s="+Company+"&f=snbaopl1");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setReadTimeout(10000 /* milliseconds */);
			connection.setConnectTimeout(15000 /* milliseconds */);
			connection.setRequestMethod("GET");
			connection.setDoInput(true);
			// Starts the query
			connection.connect();

			inputStream = connection.getInputStream();

			// Convert the InputStream into a string
			String contentAsString = stringify(inputStream, 1000);
			return contentAsString;

			// Makes sure that the InputStream is closed after the app is
			// finished using it.
		} finally {
			if (inputStream != null) {
				inputStream.close();
			} 
		}
	}

	// String conversion handler

	public String stringify(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
		Reader reader = null;
		reader = new InputStreamReader(stream, "UTF-8");        
		char[] buffer = new char[len];
		reader.read(buffer);
		return new String(buffer);
	}			

	
}

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.*;

import java.sql.SQLException;
import java.util.*;
 
public class GUIStocksInterface extends JFrame{
    JRadioButton RtoLbutton;
    JRadioButton LtoRbutton;
    static StocksDBActivity Driver;
    public JTextArea display;
    File Script;
    JFileChooser fc;
    FlowLayout experimentLayout = new FlowLayout();
    final String RtoL = "Right to left";
    final String LtoR = "Left to right";
    JButton openButton = new JButton("Read Script");
    JButton fundButton = new JButton("Fund");
    JButton individualButton = new JButton("Individual");
    JButton buyButton = new JButton("Buy");
    JButton sellButton = new JButton("Sell");
    JButton buyANDSellButton = new JButton("Buy/Sell");
    
    int width = 650, height = 300;
     
    public GUIStocksInterface(String name) {
        super(name);
    }
     
    public void addComponentsToPane(final Container pane) {
        final JPanel compsToExperiment = new JPanel();
        compsToExperiment.setLayout(experimentLayout);
        experimentLayout.setAlignment(FlowLayout.TRAILING);
        JPanel controls = new JPanel();
        controls.setLayout(new FlowLayout());
        display = new JTextArea();
		display.setFont(new Font("serif", Font.PLAIN, 14));
		JScrollPane scrollPane = new JScrollPane(display);
		scrollPane.setPreferredSize(new Dimension(9 * width / 10, 6 * height / 10));
		compsToExperiment.add(scrollPane);
		 fc = new JFileChooser();
         
        //Add buttons to the experiment layout
     
        //Left to right component orientation is selected by default
     
        controls.add(openButton);
        controls.add(fundButton);
        controls.add(individualButton);
        controls.add(buyButton);
        controls.add(sellButton);
        controls.add(buyANDSellButton);
         
        //Process the Apply component orientation button press
        openButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //Check the selection
                int returnVal = fc.showOpenDialog(GUIStocksInterface.this);
                
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    Script = fc.getSelectedFile();
                    try {
                    	Driver.read_file(Script);
                    } catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
                }
            }
        });
        fundButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //Check the selection
            	Driver.execute_fund("Bob", "2.75", "2005-01-01" );  
            }
        });
        
      //Process the Apply component orientation button press
        buyButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //Check the selection
               
                
              Driver.execute_buy("Jessica","GOOGL","500","2005-01-01");
            }
        });
        
        individualButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //Check the selection
            	Driver.execute_individual("Bob", "1234", "2012-02-03" );
            }
        });
        
        
        
        
        
        
        pane.add(compsToExperiment, BorderLayout.CENTER);
        pane.add(controls, BorderLayout.SOUTH); ;
    }
     
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     */
    private static void createAndShowGUI() {
        //Create and set up the window.
    	GUIStocksInterface frame = new GUIStocksInterface("Stocks");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Set up the content pane.
        frame.addComponentsToPane(frame.getContentPane());
        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }
     
    public static void main(String[] args) {
        /* Use an appropriate Look and Feel */
    	Driver = new StocksDBActivity();
        try {
            //UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        /* Turn off metal's use of bold fonts */
        UIManager.put("swing.boldMetal", Boolean.FALSE);
        //Schedule a job for the event dispatchi thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
                
            }
        });
    }
}